Math156 Assignment 2 Task 4 
Niklas Andie, Maximilian Stumpf, Erik Putzier
